module.exports = require('@S_E_C_R_E_T/eslint-config-node');
